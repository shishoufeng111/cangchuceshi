package com.rabbiter.oes.vo;

public class AdminResetPswVO {

}
